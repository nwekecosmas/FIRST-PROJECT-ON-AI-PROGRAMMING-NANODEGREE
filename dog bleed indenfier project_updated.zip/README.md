# Use-a-Pre-trained-Image-Classifier-to-Identify-Dog-Breeds
This project is part of Udacity's 'AI Programming with Python' Nanodegree sponsored
by AWS

Here, I used an image classifier to classify dog breeds images.
By NWEKE COSMAS UCHENNA
20TH NOVEMBER,2022
